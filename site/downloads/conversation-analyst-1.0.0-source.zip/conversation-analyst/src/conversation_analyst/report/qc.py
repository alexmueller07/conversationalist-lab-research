"""Whether a session's numbers should be trusted.

A measurement pipeline that always returns numbers is not reporting quality,
it is hiding it. Every session gets an explicit verdict with the specific
checks that produced it, so that a corpus can be filtered on evidence rather
than on a spot check of a few dashboards.

The verdict answers one question: *can the numbers this session reports be
trusted?* -- not "is this recording perfect". The distinction matters
because the pipeline already withholds what a recording cannot support: a
shared-audio session reports no overlap measures, a session with a marginal
speaker track reports no latency medians. Failing a session over a
limitation whose every affected measure was already withheld punishes the
honesty, and it teaches people to ignore the verdict column.

Four verdicts:

``pass``
    Every check clean. The numbers mean what they say.
``pass_limits``
    The recording has a named structural limitation, the affected measures
    are withheld, and everything actually reported is trustworthy. The
    limits are listed on the badge. Most Zoom-era recordings land here,
    because a shared audio feed removes overlap evidence by construction.
``review``
    Something a human should weigh before using the session -- low
    recognition confidence, marginal face coverage, a borderline turn
    count. The numbers are reported, with reasons to look at them.
``fail``
    Something fatal: the reported numbers themselves cannot be trusted.

The checks are deliberately about *inputs*, not about whether the results
look plausible. Screening out sessions whose values seem surprising is how
a real effect gets discarded.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Literal

import numpy as np

from conversation_analyst.context import AnalysisContext
from conversation_analyst.session import PERSONS

Verdict = Literal["pass", "pass_limits", "review", "fail"]

VERDICT_LABELS: dict[str, str] = {
    "pass": "PASS",
    "pass_limits": "PASS — with noted limits",
    "review": "REVIEW",
    "fail": "FAIL",
}


@dataclass
class QCCheck:
    name: str
    passed: bool
    value: float | None
    threshold: float | None
    severity: Literal["fatal", "limit", "warning"]
    """``fatal`` fails the session. ``limit`` names a structural property of
    the recording that the pipeline has already handled by withholding the
    affected measures -- it caps the verdict at ``pass_limits`` rather than
    demanding review, because there is nothing for a human to re-judge.
    ``warning`` asks for a human eye and caps the verdict at ``review``."""
    message: str


@dataclass
class QCReport:
    session_id: str
    verdict: Verdict
    checks: list[QCCheck] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)

    @property
    def failures(self) -> list[QCCheck]:
        return [c for c in self.checks if not c.passed]

    def to_dict(self) -> dict:
        return {
            "session_id": self.session_id,
            "verdict": self.verdict,
            "checks": [
                {
                    "name": c.name, "passed": c.passed, "value": c.value,
                    "threshold": c.threshold, "severity": c.severity,
                    "message": c.message,
                }
                for c in self.checks
            ],
            "warnings": self.warnings,
        }


def assess_quality(context: AnalysisContext, sync=None) -> QCReport:
    """Judge whether this session's measures are usable."""
    cfg = context.config.qc
    checks: list[QCCheck] = []

    def check(name, value, threshold, ok, severity, message):
        checks.append(QCCheck(name, bool(ok), value, threshold, severity, message))

    check(
        "duration", context.duration, cfg.min_session_s,
        context.duration >= cfg.min_session_s, "fatal",
        f"session is {context.duration:.0f}s (minimum {cfg.min_session_s:.0f}s)",
    )

    if sync is not None and sync.offsets:
        worst = min((o.confidence for o in sync.offsets.values()), default=1.0)
        check(
            "camera_sync", worst, 0.5, worst >= 0.5, "fatal",
            f"lowest cross-camera sync confidence {worst:.2f}; "
            "timing measures depend on alignment",
        )

    if context.attribution is not None:
        diag = context.attribution.diagnostics
        speech = float(diag.get("speech_proportion", 0.0))
        check(
            "speech_proportion", speech, cfg.min_speech_proportion,
            speech >= cfg.min_speech_proportion, "fatal",
            f"only {speech:.0%} of the session contains speech",
        )
        uncertain = float(diag.get("uncertain_speech_fraction", 0.0))
        check(
            "attribution_confidence", uncertain, cfg.max_attribution_uncertain,
            uncertain <= cfg.max_attribution_uncertain, "fatal",
            f"{uncertain:.0%} of speech frames could not be confidently "
            "attributed to a speaker",
        )
        for person in PERSONS:
            share = float(diag.get(f"talk_proportion_{person}", 0.0))
            check(
                f"talk_time_{person}", share, 0.02, share >= 0.02, "warning",
                f"person {person} speaks in only {share:.1%} of frames",
            )

    # Is the speaker track stable enough to define turn boundaries?
    #
    # A decoder working from weak evidence can flicker between speakers
    # several times a second while reporting high confidence, because the
    # posterior is computed from the same weak evidence that produced the
    # path. The result looks like a conversation with hundreds of turns and
    # a median floor-transfer offset of zero. Nothing downstream detects
    # this from the numbers alone, so it is checked directly -- but against
    # *corroboration*, not against the raw count of short runs. Real
    # conversation is dense with genuine 200 ms vocalisations, and most
    # short runs on real recordings carry an independently recognized word.
    # The suspect quantity is the short runs nothing vouches for.
    stability = context.short_run_corroboration()
    if stability is not None:
        raw = stability["raw_short_fraction"]
        check(
            "speaker_track_raw", raw, cfg.max_short_state_raw,
            raw <= cfg.max_short_state_raw, "fatal",
            f"{raw:.0%} of speaker-state runs are shorter than 300 ms; tracks "
            "this fragmented measure 50-60% when driven by lip motion alone, "
            "and nothing built on these boundaries is trustworthy",
        )
        uncorroborated = stability["uncorroborated_fraction"]
        check(
            "speaker_track_stability", uncorroborated,
            cfg.max_uncorroborated_short,
            uncorroborated <= cfg.max_uncorroborated_short, "fatal",
            f"{uncorroborated:.0%} of speaking runs are short and vouched for "
            "by nothing -- no recognized word, no laughter. These are states "
            "the decoder invented, and every measure built on its boundaries "
            "is unreliable",
        )
        if uncorroborated <= cfg.max_uncorroborated_short:
            timing_ok = uncorroborated <= cfg.max_uncorroborated_timing
            check(
                "timing_precision", uncorroborated, cfg.max_uncorroborated_timing,
                timing_ok, "limit",
                f"{uncorroborated:.0%} of speaking runs are uncorroborated "
                "(sound enough to count turns and behavior, not sound enough "
                "to trust millisecond boundary timing). Response-latency, "
                "floor-transfer and rhythm measures are withheld; everything "
                "reported is unaffected by boundary jitter",
            )

    # Both files carrying one shared audio feed does not merely weaken
    # overlap detection, it removes the evidence for it. A *limit*, not a
    # review flag: the pipeline detects it, withholds every affected
    # measure, and right-censoring of latencies is stated on the dashboard.
    # There is nothing left for a human to re-judge -- only a recording
    # practice to change next time.
    if context.attribution is not None:
        identifiable = float(
            context.attribution.diagnostics.get("overlap_identifiable", 1.0)
        )
        check(
            "overlap_measurable", identifiable, 1.0, identifiable > 0.5, "limit",
            "the two files carry the same mixed audio, so simultaneous speech "
            "cannot be detected (measured recall never exceeds 0.26). Overlap "
            "and interruption measures are withheld, and response latencies "
            "are right-censored at zero because an unresolved overlap collapses "
            "into a hard speaker switch. Recording a separate audio file per "
            "participant removes the limitation entirely",
        )

    if context.turn_set is not None:
        n_turns = len(context.turn_set.turns)
        ftos = context.turn_set.all_ftos()
        if ftos.size >= 20:
            negative = float(np.mean(ftos < 0))
            check(
                "overlapping_onset_rate", negative, cfg.max_overlapping_onsets,
                negative <= cfg.max_overlapping_onsets, "fatal",
                f"{negative:.0%} of turns begin before the previous speaker "
                "finished; in natural conversation this is 10-20%, so the turn "
                "boundaries are probably wrong",
            )
        # Two separate questions, and an absolute count conflates them.
        # Whether a conversation happened at all is a matter of *rate*: 18
        # turns in one minute is a lively exchange, 18 turns in ten minutes is
        # barely an interaction. Whether its turn-level statistics can be
        # trusted is a matter of *count*, because a median needs a sample.
        # Judging both with one absolute threshold fails every short session
        # regardless of how good it is.
        check(
            "turn_count_minimum", float(n_turns), float(cfg.min_turns_absolute),
            n_turns >= cfg.min_turns_absolute, "fatal",
            f"only {n_turns} turns detected; no turn-level statistic is "
            "meaningful below about "
            f"{cfg.min_turns_absolute}",
        )
        check(
            "turn_count_reliable", float(n_turns), float(cfg.min_turns),
            n_turns >= cfg.min_turns, "warning",
            f"{n_turns} turns; medians and IQRs are noisy below {cfg.min_turns}",
        )
        if context.duration > 0:
            rate = n_turns / (context.duration / 60.0)
            check(
                "turn_rate", rate, cfg.min_turn_rate,
                rate >= cfg.min_turn_rate, "fatal",
                f"{rate:.1f} turns per minute; below {cfg.min_turn_rate} this "
                "is not a two-way conversation",
            )

    # Recording quality. Freezing and near-zero motion are *limits*: the
    # view cannot support movement measures, the pipeline withholds every
    # facial and body measure built on it (see the reliability gate in the
    # pipeline), and what remains reported -- turn-taking, prosody, lexical
    # -- is untouched by the problem. A frozen frame produces confident,
    # stable tracking of a face that is not moving, so reporting those
    # measures with a warning attached was worse than not reporting them.
    for role, quality in (context.video_quality or {}).items():
        if np.isfinite(quality.freeze_rate):
            check(
                f"video_continuity_{role}", quality.freeze_rate, cfg.max_freeze_rate,
                quality.freeze_rate <= cfg.max_freeze_rate, "limit",
                f"{quality.freeze_rate:.0%} of sampled frame pairs in {role} are "
                "identical; the picture freezes, so facial and body measures "
                "from this view are withheld rather than reported from a held "
                "frame",
            )
        if np.isfinite(quality.motion):
            check(
                f"video_motion_{role}", quality.motion, cfg.min_motion,
                quality.motion >= cfg.min_motion, "limit",
                f"only {quality.motion:.1%} of pixels change between frames in "
                f"{role}; the view cannot support movement measures, so facial "
                "and body measures from it are withheld",
            )
        if quality.height:
            check(
                f"video_resolution_{role}", float(quality.height),
                float(cfg.min_video_height), quality.height >= cfg.min_video_height,
                "warning",
                f"{role} is {quality.width}x{quality.height}; facial action "
                "estimates degrade as the face occupies fewer pixels",
            )
    for role, quality in (context.audio_quality or {}).items():
        if np.isfinite(quality.snr_db):
            check(
                f"audio_snr_{role}", quality.snr_db, cfg.min_snr_db,
                quality.snr_db >= cfg.min_snr_db, "warning",
                f"{role} signal-to-noise is {quality.snr_db:.0f} dB; pitch "
                "measures and level-based speaker attribution both degrade "
                f"below {cfg.min_snr_db:.0f} dB",
            )

    if context.transcript is not None:
        confidence = context.transcript.mean_confidence
        if np.isfinite(confidence):
            check(
                "asr_confidence", confidence, cfg.min_asr_confidence,
                confidence >= cfg.min_asr_confidence, "warning",
                f"mean word confidence {confidence:.2f}; lexical and semantic "
                "measures are unreliable below this",
            )

    if context.face:
        for person, signals in context.face.items():
            check(
                f"face_coverage_{person}", signals.coverage, cfg.min_face_coverage,
                signals.coverage >= cfg.min_face_coverage, "warning",
                f"face tracked in {signals.coverage:.0%} of frames for {person}",
            )

    fatal = [c for c in checks if not c.passed and c.severity == "fatal"]
    warned = [c for c in checks if not c.passed and c.severity == "warning"]
    limited = [c for c in checks if not c.passed and c.severity == "limit"]
    verdict: Verdict = (
        "fail" if fatal
        else "review" if warned
        else "pass_limits" if limited
        else "pass"
    )

    return QCReport(
        session_id=context.session_id,
        verdict=verdict,
        checks=checks,
        warnings=list(context.warnings),
    )
